# Bear X Axis And Extruder

## Optional parts made by the community

Designed by the community. Huge thank you all, you are making this extruder even better!

| Description | Author | Link |
|:-----------:|:------:|:----:|
| E3D Volcano Extruder for MK3 Bear conversion | ufoDziner | https://www.thingiverse.com/thing:3166998 |
| Serious business Bear X-axis replacement | zbrozek | https://www.thingiverse.com/thing:3194456 |
| Big Bearing Bear X-Axis end | ufoDziner | https://www.thingiverse.com/thing:3243705 |
| Bear X end motor with bearing support | ilya_tsaryuk | https://www.thingiverse.com/thing:3249583 |
| Bear Extruder BLTouch Mount | vertigo235 | https://www.thingiverse.com/thing:3251530 |
| Y-Axis Bearing holders | MartinMajewski | https://www.thingiverse.com/thing:3342147 |
| Bear Extruder MK2S based on 0.6.0-alpha | Ringo1508 |https://www.thingiverse.com/thing:3252121 |
| Bear extruder with hobbed pulley from MK2S | toto99303 | https://www.thingiverse.com/thing:3661475 |
| MMU2S Door Sensor for Bear Extruder | vertigo235 | https://www.thingiverse.com/thing:3472911 |
| Nema 17 Gearbox "Pullybox" Mod for Extruder | vertigo235 | https://www.thingiverse.com/thing:3714978 |
| Bear extruder for Slice Mosquito Hotend | Ben's 3D | https://www.thingiverse.com/thing:3733768 |
