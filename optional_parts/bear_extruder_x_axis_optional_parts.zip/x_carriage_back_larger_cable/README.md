# Bear X Axis And Extruder

## X carriage back for larger filament sensor cable

This is a remix of the original Bear extruder X carriage back to allow use of larger cables like the MK2.5/MK3 laser filament sensor cable (for [Bondtech X carriage](../bondtech_x_carriage) for example).

Left is standard X carriage back and right is the larger one proposed here.

![X carriage backs](x_carriage_back_larger_fs_cables.jpg)
